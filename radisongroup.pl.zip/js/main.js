$(function() {
    $('.clearFilterButton').click(function() {
		$('#clearFilter').val(1); 
		$('#filterForm').submit();
	});
	
	$('.datepicker').each(function() {
		id = '#'+$(this).attr('id');
		$(id).datepicker({dateFormat: 'yy-mm-dd'});
	});
});

function currency(number) {
    if(number === null || number === 'null' || number === '') {
        return '';
    }
    
    numberString = number.toFixed(2).replace('.', ',');
    return numberString+' zł';
}

FrontCommon = {
    autocompleteShowAll: function(object) {
        wasOpen = false;
        $(object).parent('div').css('position', 'relative');
        $( "<a>" )
            .attr("tabIndex", -1)
            .attr("title", "Pokaż wszystkie")
            .appendTo($(object).parent('div'))
            .button({
                icons: {
                  primary: "ui-icon-triangle-1-s"
                },
                text: false
            })
            .removeClass( "ui-corner-all" )
            .css({
                height: $(object).outerHeight() - 6,
                position: 'absolute',
                right: $(object).parent('div').outerWidth() - $(object).outerWidth(),
                top: '5px'
            })
            .addClass( "custom-combobox-toggle ui-corner-right" )
            .mousedown(function() {
                wasOpen = $(object).autocomplete( "widget" ).is( ":visible" );
            })
            .click(function() {
                $(object).trigger( "focus" );
    
                // 
                if ( wasOpen ) {
                  return;
                }

                // 
                $(object).autocomplete( "search", "" );
            });
    },
    getNotificationsInfo: function() {
        $.getJSON({
            url: '/customers/get-notifications-info',
            success: function(result) {
                if(result.newOrdersNumber > 0) {
                	$('#newOrdersNotification').html(result.newOrdersNumber);
                	$('#newOrdersNotification').show();
                } else {
                	$('#newOrdersNotification').html('');
                	$('#newOrdersNotification').hide();
                }
                if(result.newOffersNumber > 0) {
                	$('#newOffersNotification').html(result.newOffersNumber);
                	$('#newOffersNotification').show();
                } else {
                	$('#newOffersNotification').html('');
                	$('#newOffersNotification').hide();
                }
                if(result.newMessagesNumber > 0) {
                	$('#newMessagesNotification').html(result.newMessagesNumber);
                	$('#newMessagesNotification').show();
                } else {
                	$('#newMessagesNotification').html('');
                	$('#newMessagesNotification').hide();
                }
            },
            error: function( jqXHR, textStatus, errorThrown) {
                if(jqXHR.status == 403) {
                    clearInterval(ih);
                }
            }
        });
    },
    copyToClipboard: function(object) {
        $(object).select();
        document.execCommand('copy');
    }
};